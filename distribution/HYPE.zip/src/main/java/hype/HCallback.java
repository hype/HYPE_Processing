package hype;

public interface HCallback {
	public void run(Object obj);
}
