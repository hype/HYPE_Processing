package hype.interfaces;

public interface HLocatable {
	/**
	 * TODO
	 *
	 * @return
	 */
	public float x();

	/**
	 * TODO
	 *
	 * @chainable
	 * @param f
	 * @return
	 */
	public HLocatable x(float f);

	/**
	 * TODO
	 *
	 * @return
	 */
	public float y();

	/**
	 * TODO
	 *
	 * @chainable
	 * @param f
	 * @return
	 */
	public HLocatable y(float f);

	/**
	 * TODO
	 *
	 * @return
	 */
	public float z();

	/**
	 * TODO
	 *
	 * @chainable
	 * @param f
	 * @return
	 */
	public HLocatable z(float f);
}
