package hype.core.interfaces;

public interface HRotatable {
	public float rotationRad();
	public HRotatable rotationRad(float rad);
}
