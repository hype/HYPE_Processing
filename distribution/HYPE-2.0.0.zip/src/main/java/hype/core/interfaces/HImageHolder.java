package hype.core.interfaces;

import processing.core.PImage;

public interface HImageHolder {
	public HImageHolder image(Object imgArg);
	public PImage image();
}
