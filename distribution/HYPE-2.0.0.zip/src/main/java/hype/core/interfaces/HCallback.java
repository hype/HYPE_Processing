package hype.core.interfaces;

public interface HCallback {
	public void run(Object obj);
}
