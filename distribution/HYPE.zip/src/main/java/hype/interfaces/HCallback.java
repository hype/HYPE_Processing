package hype.interfaces;

public interface HCallback {
	public void run(Object obj);
}
