import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import hype.*; 
import hype.extended.behavior.HProximity; 
import hype.extended.layout.HGridLayout; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class HProximity_002 extends PApplet {





public void setup() {
	
	H.init(this).background(0xff242424);

	HDrawablePool pool = new HDrawablePool(576);
	pool.autoAddToStage()
		.add(new HRect(25).rounding(4).noStroke().fill(0xffECECEC).anchorAt(H.CENTER))
		.layout(new HGridLayout().startLoc(21, 21).spacing(26, 26).cols(24))
		.onCreate(
			new HCallback() {
				public void run(Object obj) {
					HDrawable d = (HDrawable) obj;
            		
            		new HProximity().target(d);
				}
			}
		)
		.requestAll()
	;
}

public void draw() {
	H.drawStage();
}
  public void settings() { 	size(640, 640); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HProximity_002" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
