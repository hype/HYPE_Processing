package hype.core.interfaces;

public interface HDirectable extends HLocatable, HRotatable {}
