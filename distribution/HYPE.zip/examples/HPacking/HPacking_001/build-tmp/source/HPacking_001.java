import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import hype.*; 
import hype.extended.behavior.HPacking; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class HPacking_001 extends PApplet {




HDrawablePool pool;
HPacking circle_packing;

public void setup() {
	
	
	H.init(this).background(0xff242424);

	circle_packing = new HPacking();

	pool = new HDrawablePool(100);
	pool.autoAddToStage()
		.add(new HEllipse())
		.onCreate(
			 new HCallback() {
				public void run(Object obj) {
					HEllipse d = (HEllipse) obj;
					d.fill(255).noStroke();

					circle_packing.addTarget(d);
				}
			}
		)
		.requestAll()
	;
}

public void draw() {
	H.drawStage();
	surface.setTitle("FPS: " + frameRate);
}

public void mousePressed() {
	circle_packing.reset();
	circle_packing.maxSize(random(100, 800));
	
	for (HDrawable d : pool) {
		circle_packing.addTarget(d);
	}

	//pool.drain();
	//pool.requestAll();
}
  public void settings() { 	size(640,640,P3D); 	smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HPacking_001" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
