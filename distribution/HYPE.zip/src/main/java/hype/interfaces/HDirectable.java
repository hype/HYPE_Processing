package hype.interfaces;

public interface HDirectable extends HLocatable, HRotatable {}
