import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import hype.*; 
import hype.extended.behavior.HProximity; 
import hype.extended.layout.HGridLayout; 
import hype.extended.colorist.HColorField; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class HProximity_003 extends PApplet {






HDrawablePool pool;
HColorField   colorField;

public void setup() {
	
	H.init(this).background(0xff242424);

	colorField = new HColorField(width, height).addPoint(0, height/2, 0xffFF0066, 0.5f).addPoint(width, height/2, 0xff3300FF, 0.5f).fillOnly();

	pool = new HDrawablePool(576);
	pool.autoAddToStage()
		.add(new HRect(25))
		.layout(new HGridLayout().startX(21).startY(21).spacing(26, 26).cols(24))
		.onCreate(
			new HCallback() {
				public void run(Object obj) {
					int i = pool.currentIndex();

					HDrawable d = (HDrawable) obj;
					d.noStroke().fill(0xff000000).anchorAt(H.CENTER);

					colorField.applyColor(d);

					new HProximity().target(d);
				}
			}
		)
		.requestAll()
	;
}

public void draw() {
	H.drawStage();
}
  public void settings() { 	size(640, 640); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "HProximity_003" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
